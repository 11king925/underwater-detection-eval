# Underwater Detection Feature Interface

A small PyTorch utility for projecting multi-scale feature maps to a common
channel width while preserving each level's spatial resolution.

## Quick start

```sh
python -m pip install -r requirements.txt
python run_demo.py --config example_compact.json
python run_demo.py --config example_four_levels.json
```

The demo creates synthetic tensors and prints their shapes after projection.
The two example configurations show how to set channel counts, spatial sizes,
and batch size for three- and four-level feature pyramids.
