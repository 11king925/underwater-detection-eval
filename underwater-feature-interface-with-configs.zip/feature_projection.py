"""Independent channel projection for a tuple of feature maps."""

from collections.abc import Sequence

from torch import Tensor, nn


class PyramidChannelProjection(nn.Module):
    """Project each input level without changing its spatial resolution."""

    def __init__(self, in_channels: Sequence[int], out_channels: int):
        super().__init__()
        if not in_channels or out_channels <= 0 or any(c <= 0 for c in in_channels):
            raise ValueError("Provide at least one level and positive channel counts.")
        self.projections = nn.ModuleList(
            nn.Conv2d(channels, out_channels, kernel_size=1)
            for channels in in_channels
        )

    def forward(self, features: Sequence[Tensor]) -> tuple[Tensor, ...]:
        if len(features) != len(self.projections):
            raise ValueError("Provide one feature map per configured level.")
        return tuple(
            projection(feature)
            for projection, feature in zip(self.projections, features)
        )
