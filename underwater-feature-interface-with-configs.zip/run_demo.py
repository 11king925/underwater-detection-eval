"""Run feature projection on synthetic tensors from a JSON config."""

import argparse
import json
from pathlib import Path

import torch

from feature_projection import PyramidChannelProjection


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()

    config = json.loads(args.config.read_text(encoding="utf-8"))
    channels = config["in_channels"]
    sizes = config["spatial_sizes"]
    batch_size = config["batch_size"]
    if len(channels) != len(sizes):
        parser.error("Specify one spatial size per input channel count.")
    if batch_size < 1 or any(height < 1 or width < 1 for height, width in sizes):
        parser.error("Batch size and spatial dimensions must be positive.")

    projection = PyramidChannelProjection(channels, config["out_channels"]).eval()
    inputs = tuple(
        torch.randn(batch_size, count, height, width)
        for count, (height, width) in zip(channels, sizes)
    )
    with torch.inference_mode():
        outputs = projection(inputs)

    for level, (input_map, output_map) in enumerate(zip(inputs, outputs), start=1):
        print(f"Level {level}: {tuple(input_map.shape)} -> {tuple(output_map.shape)}")


if __name__ == "__main__":
    main()
